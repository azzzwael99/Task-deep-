import yfinance as yf
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import cv2
import os
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, Flatten, LSTM, Dense, Reshape
from sklearn.model_selection import train_test_split

# تحميل بيانات سهم معين
symbol = "TSLA"
data = yf.download(symbol, start="2020-01-01", end="2024-01-01")

# إنشاء مجلد لحفظ الصور
charts_dir = "charts"
os.makedirs(charts_dir, exist_ok=True)

# توليد الرسوم البيانية للأسعار
def save_chart(data, filename):
    plt.figure(figsize=(5, 5))
    plt.plot(data['Close'], color='blue', label='Close Price')
    plt.legend()
    plt.savefig(filename)
    plt.close()

# حفظ الرسوم البيانية لكل 30 يوم
window_size = 30
for i in range(len(data) - window_size):
    subset = data.iloc[i : i + window_size]
    save_chart(subset, f"{charts_dir}/chart_{i}.png")

# تجهيز البيانات
image_size = (64, 64)
X, y = [], []
file_list = sorted(os.listdir(charts_dir), key=lambda x: int(x.split("_")[1].split(".")[0]))

for i, file in enumerate(file_list[:-1]):  
    img = cv2.imread(f"{charts_dir}/{file}", cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, image_size)
    X.append(img)

    next_close_price = data['Close'].iloc[i + window_size]
    current_close_price = data['Close'].iloc[i + window_size - 1]
    price_change = (next_close_price - current_close_price) / current_close_price
    y.append(price_change)

X = np.array(X).reshape(-1, image_size[0], image_size[1], 1) / 255.0
y = np.array(y)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# بناء نموذج CNN-LSTM
input_layer = Input(shape=(64, 64, 1))
x = Conv2D(32, (3, 3), activation='relu', padding='same')(input_layer)
x = MaxPooling2D((2, 2))(x)
x = Conv2D(64, (3, 3), activation='relu', padding='same')(x)
x = MaxPooling2D((2, 2))(x)
x = Conv2D(128, (3, 3), activation='relu', padding='same')(x)
x = MaxPooling2D((2, 2))(x)
x = Flatten()(x)
x = Reshape((1, -1))(x)
x = LSTM(64, return_sequences=False)(x)
x = Dense(32, activation='relu')(x)
output_layer = Dense(1)(x)

model = Model(inputs=input_layer, outputs=output_layer)
model.compile(optimizer='adam', loss='mse')

# تدريب النموذج
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

# حفظ النموذج
model.save("stock_price_cnn_lstm.h5")

# التنبؤ وعرض النتائج
y_pred = model.predict(X_test)

plt.figure(figsize=(10, 5))
plt.plot(y_test, label="Actual Price Change", color='blue')
plt.plot(y_pred, label="Predicted Price Change", color='red')
plt.legend()
plt.savefig("prediction_results.png")
