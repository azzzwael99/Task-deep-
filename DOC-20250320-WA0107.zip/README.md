# Stock Price Prediction using CNN-LSTM

## Project Description
This project uses CNN-LSTM to predict stock price movements based on financial charts. It utilizes Yahoo Finance data, processes it into candlestick charts, extracts features using CNN, and predicts future trends with LSTM.

## Requirements
- Python 3.x
- TensorFlow
- Keras
- NumPy
- Pandas
- Matplotlib
- OpenCV
- Yahoo Finance API

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the script: `python stock_price_prediction.py`

## Output
- Model: `stock_price_cnn_lstm.h5`
- Prediction Chart: `prediction_results.png`
